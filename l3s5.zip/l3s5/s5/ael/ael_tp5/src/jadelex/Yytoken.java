package jadelex;
/**
 *  Jade Tokenizer  result
 */
public interface Yytoken {

    TokenType getType();
}