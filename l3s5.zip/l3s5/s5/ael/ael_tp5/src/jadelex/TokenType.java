package jadelex;

public enum TokenType {
	MOVE, PEN_MODE, JUMP, STEP_LENGTH, REPEAT, UNKNOWN, BEGIN, END, IDENT, DEFINE;
}