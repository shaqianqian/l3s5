package postfixees;
public interface Yytoken {
 /**
  * Chaîne source du token
  **/
 String image();
 String nom();
 
 
}