schema([a,b,c,d,e,f,g,h,i,j]).
fds([ [[a,b],[c]], [[b,d],[e,f]], [[b],[f]], [[f],[g,h]],[[d],[i,j]] ]).
