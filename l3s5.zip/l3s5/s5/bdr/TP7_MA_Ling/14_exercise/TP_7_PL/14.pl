schema([mn,yr,p,mp,c]).
fds([ [[mn],[mp]],[[mn,yr],[p]],[[mp],[c]] ]).
decomp([mn,yr,p],[mn,mp,c]).
