package pisine;

public class Cubicle {


}
