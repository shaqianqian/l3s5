package fil.coo.Questionnaire_sha_ma;


public class Answer {
  String type;
  String answer;
  int point;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}
public int getPoint() {
	return point;
}
public void setPoint(int point) {
	this.point = point;
}

}
