package tests.main;

public class ServiceTwo extends Service {

	public int cost() {
		return 200;
	}

	public void execute() {
		// do something for ServiceTwo
	}

}
