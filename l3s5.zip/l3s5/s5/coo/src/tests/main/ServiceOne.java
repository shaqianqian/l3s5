package tests.main;

public class ServiceOne extends Service {

	public int cost() {
		return 100;
	}

	public void execute() {
		// do something for ServiceOne
	}

}
