package tests.main;

public class NotEnoughMoneyException extends Exception {

}
