package generic.content;

public class Coffee implements Content, Edible {

	public int volume() {
		return 0;
	}

}
