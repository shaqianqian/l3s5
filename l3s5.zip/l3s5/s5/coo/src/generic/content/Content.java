package generic.content;

public interface Content {
	/** return the volume of this content
	 * @return the volume of this content
	 */
	public int volume();
}
