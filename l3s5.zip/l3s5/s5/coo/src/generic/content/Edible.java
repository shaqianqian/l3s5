package generic.content;

public interface Edible {

}
