package design.bad;

public enum Operation {
	totalRainfall, maxTemperature, minTemperature;
}
