package design;

public class Logger {
	public void register(String msg) {
		
	}
}
