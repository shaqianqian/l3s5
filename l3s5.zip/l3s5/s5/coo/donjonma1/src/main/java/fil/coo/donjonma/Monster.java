package fil.coo.donjonma;

public class Monster extends Character{
	private int blood;
	private int bourse;
	Monster m;

	Monster(int blood, int bourse) {
		this.blood = blood;
		this.bourse = bourse;

	}
}
