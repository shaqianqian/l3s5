Auteurs : Honore Nintunze et Valentin Pierart

Le mshell marche bien dans l'ensemble sauf pour le pipe, on n'a pas trouvé pourquoi.
