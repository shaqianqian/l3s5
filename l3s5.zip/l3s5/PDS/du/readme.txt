LIN Renjie && YANG Lu

pour ce TP, on a réussi de compter pour les fichiers ordinaires et les liens symboliques avec les fonctions mdu -b et mdu -L. Le document fdsfds est pour tester et le résulta est le même que du -b et du -L. Le résultat de test est dans shell.txt. Merci !