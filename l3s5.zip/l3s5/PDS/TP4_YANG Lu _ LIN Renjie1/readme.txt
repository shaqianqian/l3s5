TP4 LIN Renjie & YANG Lu	


readme:
  Nous avons fini les exercices 5,6 sur la support de tp. Les résultats des fichiers forkfork.c et race.c. Les résultat sont dans les fichiers forkfork.txt et race.txt. Nous avons aussi fait le makefile pour les compiler.

Pour 5.2, on n’a pas trouvé une solution, car quand le petit-fils exécute, son père est terminé. Donc il ne peut pas trouver son père et son grand-père. On pense que le double fork n’est pas très utile et c’est difficile de suivre les processus.
  
  Merci à votre attention et lecture. Nous vous souhaitons une bonne journée!