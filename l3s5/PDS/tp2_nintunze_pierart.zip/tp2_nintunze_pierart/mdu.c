/* 
Nom :
Honoré NINTUNZE
Valentin PIERART
*/

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>

#include "fatal.h"

#define SIZE 1024



static int opt_follow_links = 0;
static int opt_apparent_size = 1;
static int allouee = 0;
static int size_list = SIZE;

struct checkList {
  dev_t dev_el;
  ino_t ino_el;
};

typedef struct checkList * checkList_t;

void addToCheckList(checkList_t list, struct checkList element) {
  
  if (allouee <= size_list)
    list[allouee++] = element;
  else {
    list[allouee++] = element;
    size_list += SIZE;
    list = realloc(list,size_list*sizeof(struct checkList));
  }
    
 return ;
}


int isInCheckList(checkList_t list, struct checkList element) {
  int i,res;

  for (i = res = 0; i < allouee; i++)
    if ((element.dev_el == list[i].dev_el) && (element.ino_el == list[i].ino_el)) {
      addToCheckList(list,element);
  return 1;
    }
    
  return 0;
}

int valid_name(const char* name,checkList_t list, struct checkList element) {
  int res = strcmp(name,".") && strcmp(name,"..");
  if (res)
    if (!isInCheckList(list, element))
      addToCheckList(list, element);
  return res;
}

int getParentPathName(const char* pathname,char* res) {
  int i,j,length;
  length = strlen(pathname);
  for (i = length-1; i > 0; i--)
    if (pathname[i] == '/') 
      break;
  if (i == 0)
    return -1;

  for (j =0; j < i; j++)
    res[j] = pathname[j];
  res[j++] = '/';
  res[j] = '\0';

  return j;
}

int du_file(const char* pathname, int* link_counter) {
  struct stat st;
  int status, size;
  checkList_t liste;
  ssize_t len;
  char buf[PATH_MAX];
  liste = (checkList_t) malloc(size_list*sizeof(struct checkList));


  status  = lstat(pathname, &st);
  if (status == -1){
    fprintf(stderr,"Error in :\n\t int du_file(const char* pathname) : Impossible de récupérer les stats\n");
    exit(EXIT_FAILURE);
  }

  size =  opt_apparent_size ? st.st_size : st.st_blocks;

  if (S_ISREG(st.st_mode))
    return size;

  if (S_ISLNK(st.st_mode)) {
    if (!opt_follow_links) {
      return size;
    } else {
      if (*link_counter >= 25) {
	fprintf(stderr,"%s\n",strerror(ELOOP));
	exit(EXIT_FAILURE);
      }
      len = readlink(pathname,buf,PATH_MAX);
      if (len == -1) {
	fprintf(stderr,"Error in :\n\t int du_file(const char* pathname) : readlink() failed\n");
	exit(EXIT_FAILURE);
      } else {
	buf[len] = '\0';
	(*link_counter)++;
	return du_file(buf,link_counter);
      }
    }
  }


  if (S_ISDIR(st.st_mode)) {
    DIR* dirp;
    struct dirent * dp;
    char tmp[PATH_MAX+1];

    struct checkList element;

    element.dev_el = st.st_dev;
    element.ino_el = st.st_ino;

    
    dirp = opendir(pathname);
    if (dirp == NULL){
      fprintf(stderr,"Error in :\n\t int du_file(const char* pathname) : opendir() failed\n");
      exit(EXIT_FAILURE);
    }

    while ((dp = readdir(dirp))) {
      if (!valid_name(dp->d_name, liste, element))
	continue;

      snprintf(tmp,PATH_MAX+1,"%s/%s",pathname,dp->d_name);
      *link_counter = 0;
      size += du_file(tmp,link_counter);
    }
    closedir(dirp);
    return size;
      
  }

  return 0;
}



int main(int argc, char* argv[]) {
  int size,opt,link_counter;
  link_counter = 0;
  fatal(((argc < 2) || (argc > 4)),"./mdu : illegal argument.\n\tUsage : ./mdu [options : -B or −L] [pathname]",1);

  while ((opt = getopt(argc, argv,"LB")) != -1)
    switch(opt)
      {
      case 'L': opt_follow_links = 1; break;
      case 'B': opt_apparent_size = 0; break;
      default: exit(EXIT_FAILURE);
      }


  size = du_file(argv[argc-1],&link_counter);
  printf("%d\t%s\n", size,argv[argc-1]);
  
  return 0;
}
