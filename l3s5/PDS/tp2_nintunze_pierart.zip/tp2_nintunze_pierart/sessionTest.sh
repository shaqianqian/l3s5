#/!bin/bash
# Honoré Nintunze et Valentin Pierart

echo "Test avec du natif en parallèle avec mdu\nTest mdu sur fichier normal, affichage de la taille réelle\n"
du -b mdu.c
./mdu mdu.c

echo "Test mdu sur fichier normal, affichage de la taille apparente\n"
du -B 512 mdu.c
./mdu -B mdu.c

echo "Test mdu sur un lien symbolique normal, affichage de la taille réelle\n"
ln -s mdu.c lien
du -b lien
./mdu lien

echo "Test mdu sur un lien symbolique normal, affichage de la taille apparente\n"
du -B 512 lien
./mdu -B lien

echo "Test mdu sur un lien symbolique normal, affichage de la taille réelle, suivre le lien\n"
du -L -b lien
./mdu -L lien

echo "Test mdu sur un lien symbolique normal, affichage de la taille apparente, suivre le lien\n"
du -L -B 512 lien
./mdu -L -B lien

echo "Test mdu sur un lien symbolique avec bouble infini, affichage de la taille réelle\n"
ln -s selflink selflink
du -L selflink
./mdu -L selflink

echo "\nFin des tests.\n"

