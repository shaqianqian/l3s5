Auteurs: Honoré NINTUNZE et Valentin Pierart.

La commande make test nettoie le répartoire en enlevant les fichiers intermédiaires puis lance les différentes commandes qui créent les erreurs.

make all compile tout et lance les tests.
