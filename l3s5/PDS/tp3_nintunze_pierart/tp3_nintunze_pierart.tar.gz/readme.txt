Auteurs: Honoré NINTUNZE et Valentin Pierart.

La commande make test nettoie le répartoire en enlevant les fichiers intermédiaires puis lance les différentes commandes de test.

make all compile tout et lance les tests.

Le tail avec buffer circulaire compile mais ne revoie pas les bons résultats, je n'ai pas trouvé pourquoi.
J'ai une erreur de segementation à chaque appel mais quand j'enlève les lignes correspondant à la fonction free,
je n'ai plus d'erreur de segementation mais je n'ai pas les bonnes lignes d'affichées.
