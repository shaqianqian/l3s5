Auteurs: Honoré NINTUNZE.

La commande make test lance ./ff et ./race
Il faut attendre 4 secondes pour avoir le résultat de ./ff

make all compile tout et lance les tests.
