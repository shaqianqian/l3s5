#/!bin/bash
# Honoré Nintunze

echo -e 'Test ff et race. ff affiche son message après 4 secondes. Soyez patient :) :\n\n'
./ff
./race

echo "---------------------------------------------------"

echo -e '\nFin des tests.\n'

