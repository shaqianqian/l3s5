    TP8 mtcs -- Serveur de chat multithreadé
    
Auteurs : Honoré Nintunze & Valentin Pierart


Tout marche parfaitement, par contre nous n'avons pas bien compris ce qu'il fallait faire 
pour le dernier travail à faire "fourniture d'une bibliothèque de verrous récursifs 
(rmtx.c et rmtx.h)", que fallait-il mettre dans ces 2 fichiers?

Nous avons utilisé pthread_mutex_trylock pour resoudre le problème et nous avons tout fait dans 
le fichier cnct.c .
