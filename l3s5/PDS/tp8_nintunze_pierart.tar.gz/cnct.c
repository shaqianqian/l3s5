/*
   mtcs - a multithreaded chat serveur
   Philippe Marquet, Apr 2005

   Gestion de la connexion d'un client par un thread
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <errno.h>

#include "config.h"
#include "tools.h"
#include "cnct.h"

/* Gestion des sockets */
static int sockets[MAX_CONNECTION]; /* tableau initialisé a zero */
static int received[MAX_CONNECTION]; /* tableau initialisé a zero */

pthread_mutex_t lock;
pthread_mutex_t lockStat;

static struct {
  int nbClients;
  int nbLineR;
  int nbLineS;
  int nbMaxClients_t;
  int nbMaxLineR_client;
  int nbMaxLineS_client;
} st;

static void
add_socket(int fd)
{
  int i;

  pgrs_in();

  /*---------*/
  pthread_mutex_lock(&lockStat);/* mettre à jour la structure */
  st.nbClients++;
  if(st.nbClients > st.nbMaxClients_t)
    st.nbMaxClients_t++;
  pthread_mutex_unlock(&lockStat);
  /*---------*/

  for (i=0; i<MAX_CONNECTION; i++) {
    if (sockets[i] == 0) {
      sockets[i] = fd;
      break;
    }
  }
  assert(i!=MAX_CONNECTION);
  pgrs_out();
}

static void
del_socket(int fd)
{
  int i;

  pgrs_in();

  for (i=0; i<MAX_CONNECTION; i++) {
    if (sockets[i] == fd) {
      sockets[i] = 0;
      /*---------*/
      pthread_mutex_lock(&lockStat);/* mettre à jour la structure */
      st.nbClients--;
      received[i] = 0;
      pthread_mutex_unlock(&lockStat);
      /*---------*/
      break;
    }
  }
  assert(i!=MAX_CONNECTION);
  pgrs_out();
}

/* Un client  */
static void*
repeater(void* arg)
{
  char buf[MAX_BUFFER];
  int nbc, i,sckt/* ,Rcounter */,Scounter;
  const char WELCOME[] = "mtcs : bienvenu\n";
  sckt = (int) arg;
  Scounter = 0; /* compteur pour le nombre de messages envoyés par ce client */
  /* Rcounter = 0;  *//* compteur pour le nombre de messages recus par ce client */

  pgrs_in();
  write(sckt, WELCOME, strlen(WELCOME));

  pgrs("enregistrement d'une socket");

  /*---------*/
  pthread_mutex_lock(&lock);
  add_socket(sckt);
  pthread_mutex_unlock(&lock);
  /*---------*/

  while (1) {
    pgrs("attente read");
    nbc = read(sckt, buf, MAX_BUFFER);
    if (nbc <= 0) {
      pgrs("fin lecture client");
      pgrs("desenregistrement d'une socket");

      /*---------*/
      pthread_mutex_lock(&lock);
      del_socket(sckt);
      pthread_mutex_unlock(&lock);
      /*---------*/

      close(sckt);
      pgrs_out();
      return NULL;
    }
    pgrs("boucle ecriture");
    for(i=0; i<MAX_CONNECTION; i++)
      if (sockets[i]){
	write(sockets[i], buf, nbc);

	/*---------*/
	pthread_mutex_lock(&lockStat);/* mettre à jour la structure */
	received[i] += 1;
	if (received[i] > st.nbMaxLineR_client)
	  st.nbMaxLineR_client = received[i];
	st.nbLineS++;
	st.nbLineR++;
	pthread_mutex_unlock(&lockStat);
	/*---------*/
      }
    Scounter++;
    
    /*---------*/
    pthread_mutex_lock(&lockStat);/* mettre à jour la structure */
    if (Scounter > st.nbMaxLineS_client)
      st.nbMaxLineS_client = Scounter;
    pthread_mutex_unlock(&lockStat);
    /*---------*/

    pgrs("fin boucle ecriture");
  }
}

/* Fonction pour imprimer les stats à l'écran */
static void
print_stat(int sig){
  time_t timer;
  char buffer[25];
  struct tm* tm_info;

  time(&timer);
  tm_info = localtime(&timer);

  strftime(buffer, 25, "%Y:%m:%d%H:%M:%S", tm_info);

  while(pthread_mutex_trylock(&lockStat) != EBUSY);

  printf("Les statistiques actuellesà l'instant %s sont :\n",buffer);

  printf("Le nombre de client actuel : %d\n",st.nbClients);
  printf("Le nombre de lignes reçues : %d\n",st.nbLineR);
  printf("Le nombre de lignes envoyées : %d\n",st.nbLineS);
  printf("Le nombre max de client connetés : %d\n",st.nbMaxClients_t);
  printf("Le nombre max de lignes reçues par un client : %d\n",st.nbMaxLineR_client);
  printf("Le nombre max de lignes envoyées par un client : %d\n\n",st.nbMaxLineS_client);

  pthread_mutex_unlock(&lockStat);

  return;
}

/* Création d'un client */
/* Version stupide. Pas de creation de thread,
   Le serveur ne peut plus accepter de connexion car il gère
   l'interaction avec le premier client.
*/
int
manage_cnct(int fd)
{
  int status;
  pthread_t thread;
 
  /*define the action for SIGUSR1 signal*/
  struct sigaction action;
  
  pgrs_in();

  action.sa_handler = *print_stat;
  
  if (sigemptyset(&action.sa_mask) < 0)
    perror("sigempty error");

  action.sa_flags = SA_RESTART;

  /*associate the action to the signal*/
  sigaction(SIGSTAT,&action,NULL);
    	

  /* init the mutex lock and create the thread for the client */
  pthread_mutex_init(&lock,NULL);
  pthread_mutex_init(&lockStat,NULL);

  status = pthread_create(&thread,NULL,repeater,(void*) fd);

  if(status != 0)
    perror("erreur creation thread");
		
  status = pthread_detach(thread);
		
  if(status != 0)
    perror("erreur detachement du thread");
		
  pgrs_out();
  return 0;
}
