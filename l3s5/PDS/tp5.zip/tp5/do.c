
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include "makeargv.h"
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>

int
main (int argc, char *argv[])
{
    int i, status,cpt=0,ifAnd=0,ifOr=0,ifCC=0,ifkill=0,ifContinue=1,success=0;
    pid_t pid;
    int exitReturn[20];
    char **cmdargv;
    for (i=1; i<argc; i++) { /* traiter argv[i] */
        /* création du argv de l'argument i */
        status = makeargv(argv[i], "\"", &cmdargv);
        assert(status>0);
        if (strcmp("--and",argv[i])==0) {
            ifAnd=1;
            cpt++;
        }else if (strcmp("--or",argv[i])==0) {
            ifOr=1;
            cpt++;
        }else if (strcmp("--cc",argv[i])==0) {
            ifCC=1;
            cpt++;
        }else if (strcmp("--kill",argv[i])==0) {
            ifkill=1;
            cpt++;
        }
        else if ((strstr(argv[i],"--"))!=NULL){
            printf("Option erreur!\n");
            exit(EXIT_FAILURE);
        }
        
        if (ifContinue) {
        switch (fork()) {
            case -1 :
                perror("erro fork");
                exit(EXIT_FAILURE);
            case 0:
                execvp(cmdargv[0],cmdargv);
                exit(EXIT_FAILURE);
            default: ;
        }
        pid=wait(&status);
        if(WIFEXITED(status)&&(strstr(argv[i],"--"))==NULL){
            exitReturn[i]=WEXITSTATUS(status);
            printf("[%s]  exit %d\n",*cmdargv,exitReturn[i]);
            success++;
            if (ifAnd&&exitReturn[i]==1&&ifCC) {
                ifContinue=0;
                printf("\nIl y a un program qui retourne 1 pour l'option --and  \nDonc on quitte.\n\n");
                
                if(!ifkill) exit(EXIT_FAILURE);
            }
            if (ifOr&&exitReturn[i]==0&&ifCC) {
                ifContinue=0;
                printf("\nIl y a un program qui retourne 0 pour l'option --or  \nDonc on quitte.\n\n");
                
                if(!ifkill) exit(EXIT_SUCCESS);
            }
        
        }else if((strstr(argv[i],"--"))==NULL){
            printf("exit erreur %s\n",argv[i]);
            exit(EXIT_FAILURE);
        }
        }
        else if(ifkill){
        printf("Commande \"%s\" est inutile d'exécuter\n",*cmdargv);
        }
        
        /* libération mémoire */
        freeargv(cmdargv);
    }
    if (ifAnd) {
        if(success==argc-cpt-1){
            printf("tous les réussissent à exécuter \n");
            exit(EXIT_SUCCESS);
        }
        else{
            printf("--and fail\n");
            exit(EXIT_FAILURE);
        }
    }
    if (ifOr) {
        if(success){
            printf("--or success \n");
            exit(EXIT_SUCCESS);
        }
        printf("--and fail\n");
        exit(EXIT_FAILURE);
    }
    
    exit(EXIT_FAILURE);
}
