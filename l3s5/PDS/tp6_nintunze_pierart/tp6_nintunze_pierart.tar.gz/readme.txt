Auteurs: Honoré NINTUNZE et Valentin Pierart.

La commande make test lance ./do avec différents arguments faux ou vrais
On ne sait pas trop comment tester kill. 

make all ou make do compilent do.
