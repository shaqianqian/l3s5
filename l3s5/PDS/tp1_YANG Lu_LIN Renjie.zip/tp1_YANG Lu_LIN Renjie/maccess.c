
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <unistd.h>

int main (int argc, char **argv){
    char *tmp;
    int n=0,max=0,count=1,i;
    int lecture=1, ecriture=1, execution=1;
    char* dir=(char*) malloc(2000);
    FILE *fp;
    
    
    if (argc<=1){
        printf("maccess fail\n");
        exit(EXIT_FAILURE);
    }
    if (strcmp(argv[1],"-v")==0) {
        strcpy(dir, argv[argc-1]);
        tmp=dir;
        while (*tmp) {
            if (*tmp=='/'){
                max=max>n?max:n;
                n=0;
                count++;
            }
            else
                n++;
            tmp++;
        }
	if (count!=1)
        max=max>n?max:n;
        
        if (max>NAME_MAX) {
            printf("Une des composantes du nom du fichier est trop longue!\n");
            exit(EXIT_FAILURE);
        }/*4 ème erreur*/
        
        fp=fopen(*(argv+argc-1),"r");
        
        if(errno==36){
            printf("Le nom du ficher est trop long!\n");
            exit(EXIT_FAILURE);
        }
        /*5 ème erreur*/
        
        if(fp==NULL) {
            if(errno==2) {
                printf("Le ficher n'exist pas!\n");
                exit(EXIT_FAILURE);
            }
			/*2 ème erreur*/
            if(errno==20){
                printf("Une des composantes du nom de ficher n'est pas un répertoire!\n");
                exit(EXIT_FAILURE);
            }
			/*3 ème erreur*/
            if(errno==40){
                printf("Le nom du fichier comporte trop de liens symboliques!\n");
                exit(EXIT_FAILURE);
            }
			/*6 ème erreur*/
        }
        
       for(i=2;argv[i][0]=='-';i++)
        {

            if(argv[i][1]=='r')
            {/*demander lecture*/
                if(access(argv[argc-1],R_OK))
                    lecture=-1;
            }
            if(argv[i][1]=='w')
            {/*demander écriture*/
                if(access(argv[argc-1],W_OK))
                    ecriture=-1;
            }
            if(argv[i][1]=='x')
            {/*demander exécution*/
                if(access(argv[argc-1],X_OK))
                    execution=-1;
            }
            if(lecture==-1||ecriture==-1||execution==-1)
            {
                printf("Le droit d'accès demandé au ficher n'est pas positionné!\n"); 
		/*erreur 1*/
                exit(EXIT_FAILURE);
            }
        }
        
        if(errno!=0){
			printf("Autre erreur!\n");
			printf("errno value: %d, it means: %s\n",errno, strerror(errno));
			exit(EXIT_FAILURE);
		}
		/* 7 ème erreur */
    }
exit(EXIT_SUCCESS);
}
