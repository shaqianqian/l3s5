#include <limits.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
	printf("La valeur de NAME_MAX est %d\n",NAME_MAX);
	printf("La valeur de PATH_MAX est %d\n",PATH_MAX);
	return 0;
}
