Auteurs: Honoré NINTUNZE et Valentin Pierart.

make all compile tout et lance les tests.

La commande make test nettoie le répartoire en enlevant les fichiers intermédiaires puis lance les différentes commandes de test.

Pour afficher la fonction sur gnuplot il faut écrire 

	make affiche 

dans le terminal.

On remarque que plus le buffer est petit, plus le temps d'execution est long. Mais ce phenomene
est present aussi lorsque le buffer est trop grand (cependant cela se voit mieux lorsque le fichier
est tres grand). Il faut donc un buffer dont la taille se trouve aux alentours de 1024 octets.
