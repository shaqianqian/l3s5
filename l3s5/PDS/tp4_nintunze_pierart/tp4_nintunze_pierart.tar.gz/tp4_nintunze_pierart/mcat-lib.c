/* 
Nom :
Honoré NINTUNZE
Valentin PIERART
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "fatal.h" 


void mcat(char* name) {
  int status;
  FILE* file;

  file = fopen(name,"r");

  while ((status = fgetc(file)) != EOF) {
    fputc(status,file);
  }

  fclose(file);

  return;
  
}


int main(int argc, char* argv[]) {
  int i;
  fatal(argc < 2, "Argument manquant.\nUsage :\n\t./mcat-scd [nom fichier]...",EXIT_FAILURE);

  for (i = 1; i < argc; i++)
    mcat(argv[i]);

  return 0;
}
