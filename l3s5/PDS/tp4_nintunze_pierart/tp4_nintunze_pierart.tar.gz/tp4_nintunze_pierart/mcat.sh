#! /bin/sh -uf

# Les commandes à tester
MCAT=./mcat-scd
MCAT2=./mcat-scs
MCAT3=./mcat-lib
# le fichier à lui mettre en entrée
MCAT_INPUT=test.txt
# Le fichier de temps à générer
TIME_FILE=mcat-tm.dat

# la commande gnu time
TIME_CMD="/usr/bin/time"
# les options de cette commande
TIME_OPT="-f %e %U %S"

# initialisation du fichier de résultats
rm -f $TIME_FILE && echo "# bufsize real user sys" > $TIME_FILE

#evaluation des performances de la commmande mcat-scd
for size in `awk 'BEGIN { for( i=1; i<=8388608; i*=2 ) print i }'`; do
    export MCAT_BUFSIZ=$size
    echo -n "$MCAT_BUFSIZ" >> $TIME_FILE
    $TIME_CMD "$TIME_OPT" $MCAT $MCAT_INPUT > /dev/null 2>> $TIME_FILE  
done

#Affichage des courbes dans gnuplot


#comparaison temps d'exécution entre mcat-scs et mcat-lib
    echo "temps d'exécution mcat-scs"
    $TIME_CMD "$TIME_OPT" $MCAT2 $MCAT_INPUT > /dev/null
    echo "temps d'exécution mcat-lib"
    $TIME_CMD "$TIME_OPT" $MCAT3 $MCAT_INPUT > /dev/null

    echo "-------------FIN DES TESTS-------------------"

# eof
