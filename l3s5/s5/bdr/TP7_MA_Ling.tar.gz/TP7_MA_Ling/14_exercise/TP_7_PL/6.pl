schema([a,b,c,d,e]).
fds([ [[a,b],[c]], [[c,d],[e]], [[d,e],[b]] ]).
