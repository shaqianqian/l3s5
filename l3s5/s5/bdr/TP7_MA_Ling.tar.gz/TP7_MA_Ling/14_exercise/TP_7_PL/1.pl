schema([a,c,d,e,h]).
fds1([[[a],[c]], [[a,c],[d]], [[e],[a,d]], [[e],[h]]]).
fds2([ [[a],[c,d]],[[e],[a,h]]]).

