#include <limits.h>
#include <unistd.h>
#include <stdio.h>

int main(void) {
    printf("%i\n", NAME_MAX);
    printf("%i\n", PATH_MAX);
    return 0;
}
