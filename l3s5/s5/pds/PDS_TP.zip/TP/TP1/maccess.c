#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(int argc, char **argv){

    /*
     *  Initialisation
     */

    int rflag = 0; int raccess = 0;
    int wflag = 0; int waccess = 0;
    int xflag = 0; int xaccess = 0;
    int vflag = 0;
    int c;

    int errsv;

    int failure = 0;

    /*
     *  Parsing options
     */

    while ((c = getopt (argc, argv, "rwxv")) != -1)
        switch (c) {
            case 'r':
                rflag = 1;
                break;
            case 'w':
                wflag = 1;
                break;
            case 'x':
                xflag = 1;
                break;
            case 'v':
                vflag = 1;
                break;
            default:
                continue;
                /* fprintf(stderr, "Unknown option '-%c' has been ignored.\n", optopt);*/
        }

    if(access(argv[optind], F_OK)){
        errsv = errno;
		if(vflag)
			switch(errsv) {
				case EACCES:
					fprintf(stderr, "EACCES : %s\n", strerror(errsv));
					break;
				case ELOOP:
					fprintf(stderr, "ELOOP : %s\n", strerror(errsv));
					break;
				case ENAMETOOLONG:
					fprintf(stderr, "ENAMETOOLONG : %s\n", strerror(errsv));
					break;
				case ENOENT:
					fprintf(stderr, "ENOENT : %s\n", strerror(errsv));
					break;
				case ENOTDIR:
					fprintf(stderr, "ENOTDIR : %s\n", strerror(errsv));
					break;
				case EFAULT:
					fprintf(stderr, "EFAULT : %s\n", strerror(errsv));
					break;
				default:
					fprintf(stderr, "Unexpected error -> %d : %s\n", errsv, strerror(errsv));
			}
		errno = errsv;
		return EXIT_FAILURE;
    }

    /*
     *  Checking permissions
     */

    if(rflag)
        raccess = access(argv[optind], R_OK);

    if(wflag) {
        waccess = access(argv[optind], W_OK);

		/*
		 *	Checking errors that might have occured during write permission check
		 */		
		
		if (waccess && vflag) {
			errsv = errno;
			switch (errsv) {
				case ETXTBSY:
					fprintf(stderr, "ETXTBSY : %s\n", strerror(errsv));
					errno = errsv;
					return EXIT_FAILURE;
					break;
				case EROFS:
					fprintf(stderr, "EROFS : %s\n", strerror(errsv));
					errno = errsv;
					return EXIT_FAILURE;
					break;
			}
		}
	}

    if(xflag)
        xaccess = access(argv[optind], X_OK);

    /*
     *  Computing return value
     */

    failure = (rflag?raccess:0)||(wflag?waccess:0)||(xflag?xaccess:0);

    /*
     *  Checking if any error occurred (when verbose is active)
     */

    if(vflag && failure){
        fprintf(stderr, "Following permissions were declined :");
        if(rflag && raccess)
            fprintf(stderr, " -r");
        if(wflag && waccess)
            fprintf(stderr, " -w");
        if(xflag && xaccess)
            fprintf(stderr, " -x");
        fprintf(stderr, ".\n");
    }

    return failure?EXIT_FAILURE:EXIT_SUCCESS;
}
