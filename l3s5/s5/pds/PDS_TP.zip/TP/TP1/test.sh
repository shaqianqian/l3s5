#!/bin/bash
echo "Testing error catching :";
echo;

#ENOTDIR
echo "Trying to access a file through a file (as if it was a directory)";
./maccess maccess.c/unreachable -rwxv;
echo;

#ENOENT
echo "Trying to access an inexistant file";
./maccess inexistant -rwxv;
echo;

#EACCES
echo "Trying to access a file through a forbidden directory";
mkdir DeniedAccess;
chmod 000 DeniedAccess;
./maccess ./DeniedAccess/file. -rwxv;
chmod 777 DeniedAccess;
rm -r DeniedAccess;
echo;

#ELOOP
echo "Trying a symlink loop";
ln -s link linkloop;
ln -s linkloop link;
./maccess ./linkloop -rwxv;
rm linkloop;
rm link;
echo;

#EFAULT
echo "Trying to access path variable that is outside accessible address space";
./maccess $someUninitialisedPath -rwxv
echo;

#ENAMETOOLONG
echo "Trying to access a path that is bigger than PATH_MAX";
pathmax=$(getconf PATH_MAX ~)
tooBigPath=$(head -c $pathmax < /dev/zero | tr '\0' '\141')
./maccess $tooBigPath -rwxv
echo;
