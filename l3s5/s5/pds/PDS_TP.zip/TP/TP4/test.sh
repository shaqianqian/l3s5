#!/bin/bash

make

dd if=/dev/zero of=1Go bs=1M count=1k

# La commande à tester
MCAT=./mcat_scd
# le fichier à lui mettre en entrée
MCAT_INPUT=1Go
# Le fichier de temps à générer
TIME_FILE=mcat_tm.dat

# la commande gnu time
TIME_CMD="/usr/bin/time"
# les options de cette commande
TIME_OPT="-f %e %U %S"

# initialisation du fichier de résultats
rm -f $TIME_FILE && echo "# buff_size real user sys" > $TIME_FILE


for (( i=1; i<=(1<<23); i<<=1))
do
    export MCAT_BUFSIZ=$i;
    echo -n $i >> $TIME_FILE
    $TIME_CMD "$TIME_OPT" $MCAT $MCAT_INPUT > /dev/null 2>> $TIME_FILE
done

rm 1Go

gnuplot gnuplot_opt
