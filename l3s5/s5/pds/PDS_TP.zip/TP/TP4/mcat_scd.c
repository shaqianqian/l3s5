#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>

int main (int argc, char **argv){
    char *buff;
    unsigned long int buff_size;
    char **invalid_chr = 0;
    ssize_t bytes_read;
    int fd;

    buff_size = strtoul(getenv("MCAT_BUFSIZ"), invalid_chr, 10);
    assert(invalid_chr == NULL);
    buff = (char *) malloc(sizeof(char) * buff_size);

    fd = open(argv[optind], O_RDONLY);
    assert(fd != -1);

    bytes_read = -1;

    while (bytes_read) {
        bytes_read = read(fd, buff, buff_size);
        write(STDOUT_FILENO, buff, bytes_read);
    }
    free(buff);
    close(fd);

    exit(EXIT_SUCCESS);
}
