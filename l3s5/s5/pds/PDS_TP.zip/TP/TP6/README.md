Le travail a été réalisé entièrement.
