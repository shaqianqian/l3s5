#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>
#include "makeargv.h"


void kill_childs(int nb_func, pid_t pids[]) {
    int i;
    int status;

    for (i = 0; i < nb_func; i++) {
        status = kill(pids[i], SIGKILL);
        assert(status == 0 || errno == ESRCH);
    }
}

int main (int argc, char **argv) {
    int index;
    int opt;
    int nb_func;
    int orFlag = 0;
    int andFlag = 0;
    int cFlag = 0;
    int kFlag = 0;

    pid_t pid;

    int success;
    int status;
    int child_success;
    

    while ((opt = getopt (argc, argv, "oack")) != -1)
        switch (opt) {
            case 'o':
                assert(andFlag != 1);
                orFlag = 1;
                break;
            case 'a':
                assert(orFlag != 1);
                andFlag = 0;
                break;
            case 'c':
                cFlag = 1;
                break;
            case 'k':
                cFlag = 1;
                kFlag = 1;
                break;
            default:
                continue;
        }
    
    if (!(andFlag || orFlag))
        andFlag = 1;

    nb_func = argc - optind;
    /* Making an array that can contain enough child pids */
    pid_t pids[nb_func];

    /* For each func */
    for (index = 0; index < nb_func; index++) {
        char **cmdargv;

        cmdargv = makeargv(argv[index+optind]);
        assert(cmdargv != NULL);
    
        /* Forking the program */
        switch(pid = fork()) {
            case -1:
                exit(EXIT_FAILURE);
            case 0:
                /* child transforms into the command */
                /* Note that once the child executes execvp, its address space is wiped, hence you need not worry about calling freeargv here */ 
                execvp(cmdargv[0], cmdargv);
                break;

            default:
                /* parent process can free args because the child has the heap 'copied' when forked */
                pids[index] = pid;
                freeargv(cmdargv);
        }
    }

    if (andFlag) success = 1;
    else success = 0;

    /* While there are still child processes */
    while (index-- > 0) {
        /* Retrieving child pid that terminated */
        pid = wait(&status);
        assert(pid != -1);
        /* Making sure the process exited properly */
        assert(WIFEXITED(status));
        child_success = WEXITSTATUS(status)?0:1;
        /* Retrieving return status */
        /* If we look for conjonction*/
        if (andFlag) {
            /* If we want only exit codes and last child failed */
            if (cFlag && !child_success) {
                /* If we'd like to terminate all other childs*/
                if (kFlag)
                    kill_childs(nb_func, pids);
                exit(EXIT_FAILURE);
            }
            /* Otherwise computing return code*/
            success &= child_success;
        }
        /* If we look for disjonction */
        else {
            /* If we want only exit codes and last child succeeded */
            if (cFlag && child_success) {
                /* If we'd like to terminate all other childs */
                if (kFlag)
                    kill_childs(nb_func, pids);
                exit(EXIT_SUCCESS);
            }
            /* Otherwise computing return code */
            success |= child_success;
        }
    }
    exit(success?EXIT_SUCCESS:EXIT_FAILURE);
}
