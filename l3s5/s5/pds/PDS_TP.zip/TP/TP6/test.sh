#!/bin/bash

make

./do -a true || echo "Erreur : AND true a renvoyé false"
./do -o true || echo "Erreur : OR true a renvoyé false"
./do -a true false && echo "Erreur : AND true false a renvoyé true"
./do -a true true || echo "Erreur AND true true a renvoyé false"
./do -o true false || echo "Erreur : OR true false a renvoyé false"
./do -o false false && echo "Erreur OR false false a renvoyé true"
echo ""
echo "Ces commandes devraient mettre moins de 5 secondes"
time (./do -oc true "sleep 5")
time (./do -ac false "sleep 5")
echo ""
echo "Ces commandes devraient prendre 5 secondes minimum"
time (./do -oc false "sleep 5")
time (./do -ac true "sleep 5")
echo ""
echo "Ces commandes devraient prendre moins de 5 secondes"
time (./do -ock "sleep 5" true)
time (./do -ack "sleep 5" false)
