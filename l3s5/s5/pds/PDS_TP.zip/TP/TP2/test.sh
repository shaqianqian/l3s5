#!/bin/bash

test -x;

ln -s du.c mdu.c;
make


du -bL mdu.c
./mdu -bL mdu.c
du -b mdu.c
./mdu -b mdu.c

ln -s link;

./mdu -b link

mkdir test;

cd test;

touch a;

touch b;

ln -s .. c;

cd ..

du -b .
./mdu -b .
du -B 512 .
./mdu .
