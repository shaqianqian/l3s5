#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <assert.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <search.h>



#define TRUE 1
#define FALSE 0
#define LINK 1
#define BLOCKS 2
#define HASH_MAX_SIZE 255



void hash_func(char *str, struct stat *st){
    snprintf(str, HASH_MAX_SIZE-1, "%li:%li", st->st_ino, st->st_dev);
}



int has_valid_dname(struct dirent *de) {
    if(strcmp(de->d_name, ".") && strcmp(de->d_name,".."))
        return TRUE;
    else
        return FALSE;
}



int du_file(const char *pathname, int mode){
    int status;
    struct stat st;
    DIR *dir;
    struct dirent *de;
    char subdir_pathname[PATH_MAX];
    char st_hash[HASH_MAX_SIZE];
    int size = 0;
    ENTRY e;
   
    /* Retrieving file size & checking success*/
    /* Following links ? */
    if (mode & LINK)
        status = stat(pathname, &st);
    else status = lstat(pathname, &st);

    assert(status == 0);

    /* Preparing hashmap search*/
    hash_func(st_hash, &st);
    e.key = st_hash;
    e.data = (void *) 42;


    /* If found in hashmap, return 0 */
    if (hsearch(e, FIND))
        return 0;
    /* else, insertion */
    else hsearch(e, ENTER);


    /* Adding size to variable*/
    /* Either block size */
    if (!(mode & BLOCKS))
        size += st.st_blocks;
    /* Or strict size */
    else size += st.st_size;
    

    /* If file is a directory */
    if(S_ISDIR(st.st_mode)) {
        dir = opendir(pathname);
	/* Checking that the opening succeded */
        assert(dir != NULL);
        while ((de = readdir(dir)) != NULL){
	    /* If selected dir is neither . nor .. */
            if(has_valid_dname(de)){
		/* Concatenate pathname and dirname */
                snprintf(subdir_pathname, PATH_MAX, "%s/%s", pathname, de->d_name);
		/* recursively calling du_file */
                size += du_file(subdir_pathname, mode);
            }
        }
        printf("%i\t%s\n", size, pathname);
        closedir(dir);
    }
    return size;
}



int main(int argc, char **argv){
    int mode = 0;
    int c;
    int size;
    struct stat st;

    /* Creating hashmap and handling errors */
    if(!hcreate(1 << 16)){
	perror("hcreate");
        exit(EXIT_FAILURE);
    }

    /* Checking options */
    while ((c = getopt (argc, argv, "Lb")) != -1)
        switch (c) {
            case 'L':
                mode |= LINK;
                break;
            case 'b':
                mode |= BLOCKS;
                break;
            default:
                continue;
        }
    size = du_file(argv[optind], mode);

    /* Display something if file is not a dir*/
    lstat(argv[optind], &st);
    if(!(S_ISDIR(st.st_mode)))
        printf("%i\t%s\n", size, argv[optind]);

    /* Removing hashmap from memory */
    hdestroy();
    return EXIT_SUCCESS;
}
