#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid;
    int i;

    for (i = 0; i < 10; i++){
        switch(pid = fork()) {
            case -1:
                exit(EXIT_FAILURE);

            case 0:
                /* fils */
                for(i=0; i < 100000000; i++){}
                printf("%d a compté jusque 100 000 000 !\n", getpid());
                fflush(stdout);
                for(i=0; i < 100000000; i++){}
                exit(EXIT_SUCCESS);
                break;

            default:
                /* père */
                continue;
        }
    }

    for(i=0; i<10;i++){
        printf("%d s'est terminé en %d !\n", wait(NULL), i+1);
        fflush(stdout);
    }
    return 0;
}
