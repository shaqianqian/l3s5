#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <signal.h>
#include <assert.h>

/* function called when SIGINT is received */
void sigint_handler(int sig) {
    printf("\nJ'attends que mes fils meurent\n");
    fflush(NULL);
    return;
}


int main(int argc, char **argv) {
    int i;
    pid_t pid;
    assert(argc >=2);
    int nb_fils = atoi(argv[1]);
    struct sigaction sa;

    /* filling the mask */
    sigfillset(&sa.sa_mask);
    /* for each child we need to create */
    for (i = 0; i < nb_fils; i++) {
        switch(pid = fork()) {
            case -1:
                exit(EXIT_FAILURE);
            case 0:
                /* childs */
                /* making sure SIGINT signal has no effect on childs */
                assert(sigprocmask(SIG_BLOCK, &sa.sa_mask, NULL) != -1);
                while (1) {
                    printf("   Ici %d, vivant\n", getpid());
                    fflush(NULL);
                    sleep(5);
                }
                break;
            default:
                /* père */
                continue;
        }
    }
    
    system("ps T -H");
    printf("J'attend un SIGINT\n");
    fflush(NULL);

    /* SIGINT handler */
    sa.sa_handler = &sigint_handler;
    /* Removing SIGINT from filtered signals */
    sigdelset(&sa.sa_mask, SIGINT);
    /* sigint handler waiting for SIGINT */
    assert(sigaction(SIGINT, &sa, NULL) != -1);
    /* Pausing, waiting for unfiltered signals (ie SIGINT) */
    sigsuspend(&sa.sa_mask);

    /* Waiting to retrieve terminated childs */
    for (i=0; i < nb_fils; i++) {
        printf("%d a mouru\n", wait(NULL));
        fflush(NULL);
    }
}
