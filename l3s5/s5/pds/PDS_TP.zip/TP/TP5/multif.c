#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/wait.h>

typedef int (*func_t) (int);

int isOdd(int n) {
    return n%2;
}

int multif (func_t f[], int args[], int n){
    int i;
    int success;
    int status;
    pid_t pid;
    for (i = 0; i < n; i++){
        switch(pid = fork()) {
            case -1:
                exit(EXIT_FAILURE);
            case 0:
                /* fils */
                return f[i](args[i]);
                /* puis continue le main */
                break;

            default:
                /* père */
                continue;
        }
    }
    success = 1;
    for (i = 0; i < n; i++) {
        assert(wait(&status) != -1);
        assert(WIFEXITED(status));
        success &= WEXITSTATUS(status);
    }
    if (success)
        exit(EXIT_SUCCESS);
    else exit(EXIT_FAILURE);
    /* est interrompu brutalement */
}

int main (int argc, char **argv) {
    int nb_func = argc - 1;
    int i;
    int arg_tab[nb_func];
    func_t func_tab[nb_func];
    int rvalue;

    for (i=0; i < nb_func; i++) {
        arg_tab[i] = atoi(argv[i+1]);
        func_tab[i] = &isOdd;
    }

    rvalue = multif(func_tab, arg_tab, nb_func);

    return rvalue;
}
