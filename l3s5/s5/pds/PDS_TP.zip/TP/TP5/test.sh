#!/bin/bash

make all

echo "Testing multif...";
echo "Multif tests if all the given number are odd";
echo "Should return 1 (Failure)";
./multif 32 35 56;
echo $?

echo "Should return 0 (Success)";
./multif 35 37 39
echo $?

echo "Testing race...";
./race

echo "Testing observation..."
echo "The binary creates 2 childs that are immune to every signals but SIGKILL and SIGSTOP";
echo "To test observation, you need to kill one of the childs, then send SIGINT to the process, and watch the results";
echo "Sleeping 10 seconds before testing...";
sleep 10s
./observation 2
