#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <stdlib.h>

#define OFFSET 16


void mtail(int fd, int lines_to_read, int count) {
    int status;
    int count_next; /* Number of bytes to read next iteration*/
    char buff[OFFSET+1]; /*ISOC90 made me do this instead of buff[count+1]*/
    char *chr_pointer; /* Temporary pointer to a char in buff */
    int new_line_max = (lines_to_read<count)?lines_to_read:count; /* Max number of \n to consider in buff*/
    int new_line_counter = 0;
    char *new_line_arr[OFFSET]; /* new_line_max last pointers to \n in buff - Nasty ISOC90 */
    int array_filled_flag = 0; /* Flag to know if the array of pointers to \n  was filled */
    char *new_line; /* Pointer to know where to print from */
    ssize_t nb_read_bytes = 0; /* Temporary variable to fill buff*/

    /* Filling the buffer entirely */
    while (nb_read_bytes != count)
        nb_read_bytes += read(fd, buff + nb_read_bytes, count - nb_read_bytes);

    /*Initialising the position to look for \n in buff*/
    chr_pointer = buff;

    /* While we have not read the entire buffer */
    while (*chr_pointer != '\0') {
        /* If the currently read char is a \n*/
        if (*chr_pointer == '\n') {
            /* Decrementing the number of lines to read */
            lines_to_read--;
            /* Inserting the address of the \n into the array */
            new_line_arr[new_line_counter] = chr_pointer;
            /* Switching to the next cell of the array */
            new_line_counter++;
            /* If we reached the end of the array */
            if (new_line_counter == new_line_max) {
                /* Switching to the first cell of the array */
                new_line_counter = 0;
                array_filled_flag = 1;
            }
        }
        chr_pointer++;
    }
    
    /* If we reached the end of the array */
    if (array_filled_flag) {
        /* We have to print from the first remaining \n */
        new_line = new_line_arr[new_line_counter] + 1;
    }
    /* Else we print from the beginning */
    else new_line = buff;

    /* If we still have lines to read, and we are not in the last call*/
    if (lines_to_read>0 && count == OFFSET) {
        /* Trying to */
        status = lseek(fd,-2 *OFFSET, SEEK_CUR);
        /* If that failed */
        if (status == -1) {
            /*Did that fail because we tried to look before the beginning of the file ?*/
            assert(errno == EINVAL);
            /* The number of remaining chars to read is equal to the position
               of the file descriptor when we were at the beginning of the buffer */
            count_next = lseek(fd, -OFFSET, SEEK_CUR);
            /* Setting the position of the file descriptor the the beginning of the file */
            assert(lseek(fd, 0, SEEK_SET) != -1);
        }
        /* If it succeeded, we will read OFFSET bytes in the next iteration */
        else count_next = OFFSET;
        if (count_next)
        /* Recursively calling mtail if */
            mtail(fd, lines_to_read, count_next);
    }
    /* Printing */
    write(STDOUT_FILENO, new_line, count - ((int) (new_line - buff)));
}

int main(int argc, char **argv) {
    int status;
    int fd;
    int c;
    int n = 10;

    /*
     *  Parsing options
     */

    while ((c = getopt (argc, argv, "n:")) != -1)
        switch (c) {
            case 'n':
                sscanf(optarg, "%d", &n);
                break;
            default:
                continue;
        }
    
    /* Opening the file */
    fd = open(argv[optind], O_RDONLY);
    assert(fd != -1);

    /* Setting fd so that mtail will be able to read from the end */
    status = lseek(fd, -OFFSET, SEEK_END);
    assert(status != -1);

    /* First call of mtail */
    mtail(fd, n+1, OFFSET);

    /*Closing the file*/
    close(fd);

    exit(EXIT_SUCCESS);
}
