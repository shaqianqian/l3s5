#!/bin/bash

test -x;

echo "abcdefghijklmnopqrstuvwxyz" > test;

./mtail test
./mtail_stupid test

echo "Pas à voir" >> test
echo "1"  >> test
echo "2"  >> test
echo "3"  >> test
echo "4"  >> test
echo "5"  >> test
echo "6"  >> test
echo "7"  >> test
echo "8"  >> test
echo "9"  >> test
echo "10"  >> test
echo "11"  >> test
echo "12"  >> test
echo "13"  >> test
echo "14"  >> test
echo "15"  >> test
echo "16"  >> test
echo "17"  >> test
echo "18"  >> test
echo "19"  >> test
echo "20"  >> test
echo "21"  >> test
echo "22"  >> test

./mtail test -n 22
./mtail_stupid test -n 22

rm test

./mtail mtail_stupid.c -n 24;
