#define _GNU_SOURCE
#include <features.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#define OFFSET 16


void mtail(int fd, int lines_to_read, int count) {

    int status;
    int count_next; /* Number of bytes to read next iteration*/
    char buff[OFFSET+1]; /*ISO90 made me do this instead of buff[count+1]*/
    char *new_line; /* Pointer to a \n occurrence in buff*/
    char *tmp_pointer;
    ssize_t nb_read_bytes = 0;
    
    /* Filling the buffer entirely */
    while (nb_read_bytes != count)
        nb_read_bytes += read(fd, buff + nb_read_bytes, count - nb_read_bytes);

    /* Make new_line pointing to the null bytes at the end of buff*/
    new_line = buff + nb_read_bytes;
 
    /* While we find occurrences of '\n' in buff and we still need to read lines */
    while ((tmp_pointer = memrchr(buff, '\n', new_line - buff)) && lines_to_read){
        lines_to_read--;
        new_line = tmp_pointer;
    }
    
    /* If we reached the end of the buffer and there are still lines to read*/
    if (lines_to_read && count == OFFSET) {
        new_line = buff; 
        status = lseek(fd, 2* -OFFSET, SEEK_CUR);
        if (status ==  -1){
            assert(errno == EINVAL);
            /* If we tried to set fd before the beginning of the file*/
            /* Setting number of bytes to read next to the current fd */
            count_next = lseek(fd, -OFFSET, SEEK_CUR);
            /* Setting fd to 0 (ie. to the beginning of the file)*/
            lseek(fd, 0, SEEK_SET);
        }
        else count_next = OFFSET;
        mtail(fd, lines_to_read, count_next);
    }
    write(STDOUT_FILENO, new_line, nb_read_bytes - ((int) (new_line - buff)));
}

int main(int argc, char **argv) {
    int status;
    int fd;
    int c;
    int n = 10;

    /*
     *  Parsing options
     */

    while ((c = getopt (argc, argv, "n:")) != -1)
        switch (c) {
            case 'n':
                sscanf(optarg, "%d", &n);
                break;
            default:
                continue;
        }
    
    /* Opening the file */
    fd = open(argv[optind], O_RDONLY);
    assert(fd != -1);

    /* Setting fd so that mtail will be able to read from the end */
    status = lseek(fd, -OFFSET, SEEK_END);
    assert(status != -1);

    /* First call of mtail */
    mtail(fd, n+1, OFFSET);

    /*Closing the file*/
    close(fd);

    exit(EXIT_SUCCESS);
}
