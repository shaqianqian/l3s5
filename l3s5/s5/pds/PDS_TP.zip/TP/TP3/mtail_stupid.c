#include <assert.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>

#define SIZE 16

int count_nb_lines(char *pathname) {
    int fd;
    ssize_t nb_read_bytes;
    char buff[SIZE];
    int nb_lines;
    int i;

    /* opening file to be read*/
    fd = open(pathname, O_RDONLY);
    assert(fd != -1);
    /* while there is still something to read */
    while ((nb_read_bytes = read(fd, buff, SIZE)) > 0){
         for (i=0; i < nb_read_bytes; i++)
            /* for each character, is it a new line ? */
            if (buff[i] == '\n')
                nb_lines++;
    }

    /* Checking if any error occurred */
    if (nb_read_bytes == -1) {
        perror("Reading error : ");
        exit(EXIT_FAILURE);
   }

    /* Closing dir */
    close(fd);

    return nb_lines;
}

void mtail_stupid(char *pathname, int n){
    int nb_lines;
    int nb_lines_before_print;
    int fd;
    ssize_t nb_read_bytes;
    char buff[SIZE];
    int i;

    /* Counting nb of lines in the file*/
    nb_lines = count_nb_lines(pathname);

    /* If user input is greater than the number of lines in the file, reducing it */
    if (nb_lines < n) {
        n = nb_lines;
    }

    /* Counter of lines to skip */
    nb_lines_before_print = nb_lines - n;

    /* Opening the file */
    fd = open(pathname, O_RDONLY);
    assert(fd != -1);

    /* While there is still something to read */
    while((nb_read_bytes = read(fd, buff, SIZE)) > 0) {
        /* For each char inside the buffer*/
        for (i=0; i < nb_read_bytes; i++) {
            /* If we still need to skip lines */
            if (nb_lines_before_print != 0 ){
                /* Finding the newline character */
                if (buff[i] == '\n')
                    /* Decrementing the counter */
                    nb_lines_before_print--;
            }
            /* If we need to print (ie. counter reached 0)*/
            else {
                /* print remaining chars inside buffer */
                /* OTZ */
                assert(write(STDOUT_FILENO, buff + i, nb_read_bytes - i) == nb_read_bytes - i);
                break;
            }
        }
    }

    /* Checking if any error occurred */
    if (nb_read_bytes == -1) {
        perror("Reading error : ");
        exit(EXIT_FAILURE);
    }   
}


int main (int argc, char **argv){
    
    int c;
    int n = 10;    

    /*
     *  Parsing options
     */

    while ((c = getopt (argc, argv, "n:")) != -1)
        switch (c) {
            case 'n':
                sscanf(optarg, "%d", &n);
                break;
            default:
                continue;
        }

    mtail_stupid(argv[optind], n);

    exit(EXIT_SUCCESS);
}

/*              /               \
2              /                 \
3             /  ___         ___  \
4            /  /   \       /   \  \
5               |( )|       |( )|
6               \___/       \___/
7                       |
8                       |
9                      _|_
10                    (o_o)
11
12               _____     _____
13              |     \___/     |
14              \               /
15               \_,_-)_,_,_ ,-/
16                _,-)-_,-),,)_
17                 /|)/ \-| | \
18                / |(___)| | \
19               (__|^|  /   \ )    \
20         /       () () (___)/     |\
21        /|                        (_)
22       (_)            |
23                     /|
24                    (_)                   */               
