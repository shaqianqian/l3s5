package fil.coo.Plugin;

import java.util.List;


public interface PluginListener {

	 public void update(List<Plugin> plugins);


}
