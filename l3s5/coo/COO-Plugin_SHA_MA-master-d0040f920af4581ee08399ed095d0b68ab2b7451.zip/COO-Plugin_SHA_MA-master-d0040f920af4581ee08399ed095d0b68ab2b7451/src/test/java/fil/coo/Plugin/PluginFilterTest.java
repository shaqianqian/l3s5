package fil.coo.Plugin;

import java.io.File;

import junit.framework.TestCase;

public class PluginFilterTest extends TestCase {

	PluginFilter plugin=new PluginFilter();
	public void test(){
		File file=new File(".");
		assertNotNull(plugin);
	}
}
