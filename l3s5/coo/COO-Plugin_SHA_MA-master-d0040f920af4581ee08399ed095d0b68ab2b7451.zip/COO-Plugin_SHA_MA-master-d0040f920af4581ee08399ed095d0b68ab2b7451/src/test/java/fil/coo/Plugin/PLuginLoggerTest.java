package fil.coo.Plugin;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

public class PLuginLoggerTest extends TestCase {
 PluginLogger pl=new PluginLogger();
 public void testupdate(){
	 List<Plugin> plugins=new ArrayList<Plugin>();

	 assertNotNull(pl);
 }
}
