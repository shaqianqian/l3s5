package fil.coo.Plugin;

import fil.coo.Editor.AllEditorTests;
import junit.framework.Test;
import junit.framework.TestSuite;

public class AllPluginTests {

	public static Test suite() {
		TestSuite suite = new TestSuite(AllPluginTests.class.getName());
		//$JUnit-BEGIN$
		
		suite.addTestSuite(PluginFilterTest.class);
		suite.addTestSuite(PLuginLoggerTest.class);
		
		//$JUnit-END$
		return suite;
	}

}
