package fil.coo.Editor;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllEditorTests {

	public static Test suite() {
		TestSuite suite = new TestSuite(AllEditorTests.class.getName());
		//$JUnit-BEGIN$
		suite.addTestSuite(EditorTest.class);
		
		//$JUnit-END$
		return suite;
	}

}
