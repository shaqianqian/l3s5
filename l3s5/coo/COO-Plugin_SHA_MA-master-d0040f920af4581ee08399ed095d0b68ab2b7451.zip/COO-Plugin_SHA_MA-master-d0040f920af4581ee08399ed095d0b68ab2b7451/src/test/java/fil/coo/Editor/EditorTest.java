package fil.coo.Editor;

import junit.framework.TestCase;
import fil.coo.Editor.*;
public class EditorTest extends TestCase {
	
	Window frame=new Window();
    public void testaction(){
	assertNotNull(frame);
}
}
