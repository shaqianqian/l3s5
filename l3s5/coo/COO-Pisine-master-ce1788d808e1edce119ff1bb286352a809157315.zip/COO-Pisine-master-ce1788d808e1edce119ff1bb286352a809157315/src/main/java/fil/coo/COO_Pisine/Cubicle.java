package fil.coo.COO_Pisine;

public class Cubicle {


}
